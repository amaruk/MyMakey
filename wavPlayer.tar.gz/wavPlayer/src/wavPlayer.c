/*********************************************************************************************************
 *
 * File                : wavPlayer.cpp
 * Hardware Environment: BeagleBoneBlack
 * Build Environment   : GCC in BBB
 * Version             : V1.0
 * By                  : Source code collected from Internet
 *
 *********************************************************************************************************/

#define ALSA_PLAYER
//#define OSS_PLAYER

#ifdef ALSA_PLAYER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <alsa/asoundlib.h>

struct WAV_HEADER {
	char rld[4]; //riff 标志符号
	int rLen;
	char wld[4]; //格式类型（wave）
	char fld[4]; //"fmt"

	int fLen; //sizeof(wave format matex)

	short wFormatTag; //编码格式
	short wChannels; //声道数
	int nSamplesPersec; //采样频率
	int nAvgBitsPerSample; //WAVE文件采样大小
	short wBlockAlign; //块对齐
	short wBitsPerSample; //WAVE文件采样大小

	char dld[4]; //”data“
	int wSampleLength; //音频数据的大小

} wav_header;

int set_pcm_play(FILE *fp);
void checkWav(FILE *fp);

int main(int argc, char *argv[]) {
	FILE *fp;

	if(argc!=2)
	{
		printf("Usage:wav-player+wav file name\n");
		exit(1);
	}

	fp = fopen(argv[1], "rb");
	if (fp == NULL) {
		perror("open file failed:\n");
		exit(1);
	}

	checkWav(fp);

	set_pcm_play(fp);

//	fp = fopen("/root/Piano/C4.wav", "rb");
//	set_pcm_play(fp);
	return 0;
}

void checkWav(FILE *fp) {
	int nread;
	if (fp == NULL) {
		perror("open file failed:\n");
		return;
	}

	nread = fread(&wav_header, 1, sizeof(wav_header), fp);
#if 0
	printf("nread=%d\n", nread);

	//printf("RIFF 标志%s\n",wav_header.rld);
	printf("文件大小rLen：%d\n", wav_header.rLen);
	//printf("wld=%s\n",wav_header.wld);
	//printf("fld=%s\n",wav_header.fld);

	// printf("fLen=%d\n",wav_header.fLen);

	//printf("wFormatTag=%d\n",wav_header.wFormatTag);
	printf("声道数：%d\n", wav_header.wChannels);
	printf("采样频率：%d\n", wav_header.nSamplesPersec);
	//printf("nAvgBitsPerSample=%d\n",wav_header.nAvgBitsPerSample);
	//printf("wBlockAlign=%d\n",wav_header.wBlockAlign);
	printf("采样的位数：%d\n", wav_header.wBitsPerSample);

	// printf("data=%s\n",wav_header.dld);
	printf("wSampleLength=%d\n", wav_header.wSampleLength);
#endif
}

snd_pcm_t* handle; //PCI设备句柄

int set_pcm_play(FILE *fp) {
	int rc;
	int ret;
	int size;
	snd_pcm_t * handle; //PCI设备句柄
	snd_pcm_hw_params_t* params; //硬件信息和PCM流配置
	unsigned int val;
	int dir = 0;
	snd_pcm_uframes_t frames;
	char *buffer;
	char *buffer2;
	int channels = wav_header.wChannels;
	int frequency = wav_header.nSamplesPersec;
	int bit = wav_header.wBitsPerSample;
	int datablock = wav_header.wBlockAlign;
	unsigned char ch[100]; //用来存储wav文件的头信息

	rc = snd_pcm_open(&handle, "default:CARD=Headset", SND_PCM_STREAM_PLAYBACK,
			0);
	if (rc < 0) {
		perror("\nopen PCM device failed:");
		exit(1);
	}

	snd_pcm_hw_params_alloca(&params); //分配params结构体
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params_alloca:");
		exit(1);
	}
	rc = snd_pcm_hw_params_any(handle, params); //初始化params
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params_any:");
		exit(1);
	}
	rc = snd_pcm_hw_params_set_access(handle, params,
			SND_PCM_ACCESS_RW_INTERLEAVED); //初始化访问权限
	if (rc < 0) {
		perror("\nsed_pcm_hw_set_access:");
		exit(1);

	}

	//采样位数
	switch (bit / 8) {
	case 1:
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_U8);
		break;
	case 2:
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S16_LE);
		break;
	case 3:
		snd_pcm_hw_params_set_format(handle, params, SND_PCM_FORMAT_S24_LE);
		break;

	}
	rc = snd_pcm_hw_params_set_channels(handle, params, channels); //设置声道,1表示单声>道，2表示立体声
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params_set_channels:");
		exit(1);
	}
	val = frequency;
	rc = snd_pcm_hw_params_set_rate_near(handle, params, &val, &dir); //设置>频率
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params_set_rate_near:");
		exit(1);
	}

	rc = snd_pcm_hw_params(handle, params);
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params: ");
		exit(1);
	}

	rc = snd_pcm_hw_params_get_period_size(params, &frames, &dir); /*获取周期长度*/
	if (rc < 0) {
		perror("\nsnd_pcm_hw_params_get_period_size:");
		exit(1);
	}

	size = frames * datablock; /*4 代表数据快长度*/

	buffer = (char*) malloc(size);
	fseek(fp, 58, SEEK_SET); //定位歌曲到数据区

	while (1) {
		memset(buffer, 0, sizeof(buffer));
		ret = fread(buffer, 1, size, fp);
		if (ret == 0) {
			printf("歌曲写入结束\n");
			break;
		} else if (ret != size) {
			break; //Skip last bits
		}
		// 写音频数据到PCM设备
		while (ret = snd_pcm_writei(handle, buffer, frames) < 0) {
			usleep(2000);
			if (ret == -EPIPE) {
				/* EPIPE means underrun */
				fprintf(stderr, "underrun occurred\n");
				//完成硬件参数设置，使设备准备好
				snd_pcm_prepare(handle);
			} else if (ret < 0) {
				fprintf(stderr, "error from writei: %s\n", snd_strerror(ret));
			}
		}

	}

	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	free(buffer);
	return 0;
}

//注意：编译的时候应该保持“gcc -o test test.c -L. -lasound”的格式，运行的时候应该保持"./test clip2.wav"这种格式。
#endif

#ifdef OSS_PLAYER
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <linux/soundcard.h>

#define OPEN_DSP_FAILED     0x00000001      /*打开  dsp 失败!*/
#define SAMPLERATE_STATUS     0x00000002    /*samplerate status failed*/
#define SET_SAMPLERATE_FAILED  0x00000003   /*set samplerate failed*/
#define CHANNELS_STATUS       0x00000004    /*Channels status failed*/
#define SET_CHANNELS_FAILED    0x00000005   /*set channels failed*/
#define FMT_STATUS       0x00000006        /*FMT status failed*/
#define SET_FMT_FAILED     0x00000007       /*set fmt failed*/
#define OPEN_FILE_FAILED        0x00000008    /*opem filed failed*/

int dsp_fd;

int Audio_Play_Init(int nSampleRate, int nChannels, int fmt) {
	int mix_fd, status, arg;
	dsp_fd = open("/dev/audio1", O_WRONLY); /*open dsp*/
	if (dsp_fd < 0) {
		return OPEN_DSP_FAILED;
	}
	arg = nSampleRate;
	status = ioctl(dsp_fd, SOUND_PCM_WRITE_RATE, &arg); /*set samplerate*/
	if (status < 0) {
		close(dsp_fd);
		return SAMPLERATE_STATUS;
	}
	if (arg != nSampleRate) {
		close(dsp_fd);
		return SET_SAMPLERATE_FAILED;
	}
	arg = nChannels; /*set channels*/
	status = ioctl(dsp_fd, SOUND_PCM_WRITE_CHANNELS, &arg);
	if (status < 0) {
		close(dsp_fd);
		return CHANNELS_STATUS;
	}
	if (arg != nChannels) {
		close(dsp_fd);
		return SET_CHANNELS_FAILED;
	}
	arg = fmt; /*set bit fmt*/
	status = ioctl(dsp_fd, SOUND_PCM_WRITE_BITS, &arg);
	if (status < 0) {
		close(dsp_fd);
		return FMT_STATUS;
	}
	if (arg != fmt) {
		close(dsp_fd);
		return SET_FMT_FAILED;
	}/*到此设置好了DSP的各个参数*/

	//close(dsp_fd);
	return 0;
}
int P8100_Audio_Play(char *pathname) {
	int mix_fd, status, arg;

	FILE *file_fd = fopen(pathname, "r");
	fseek(file_fd,58,SEEK_SET); //定位歌曲到数据区
	////
	//FILE *file_fd2 = fopen(pathname, "r");
	printf("Round 1\n");
	////
	if (file_fd == NULL) {
		return OPEN_FILE_FAILED;
	}
	//int num = 3 * nChannels * nSampleRate * fmt / 8;
	int num = 3 * 2 * 16;
	int get_num;
	char buf[num];
	while (feof(file_fd) == 0) {
		get_num = fread(buf, 1, num, file_fd);
		////
		//printf("get_num: %d\n", get_num);
#if 0
		{
			static int i = 0;
			if (500 < ++i)
			{
				get_num = fread(buf, 1, num, file_fd2);
				//write(dsp_fd, buf, get_num);
			}
		}
#endif
		////
		if (get_num != num) {
			printf("Skip last %d bits, num %d\n", get_num, num);
			//fclose(file_fd);
			//return 0;
			break;
		}
		write(dsp_fd, buf, get_num);


	}
	///
#if 0
	printf("Round 2\n");
	file_fd = fopen(pathname, "r");
	fseek(file_fd,58,SEEK_SET);//定位歌曲到数据区
	while (feof(file_fd) == 0) {
		get_num = fread(buf, 1, num, file_fd);
		////
#if 0
		{
			static int i = 0;
			if (500 < ++i)
			{
				get_num = fread(buf, 1, num, file_fd2);
				//write(dsp_fd, buf, get_num);
			}
		}
#endif
		////
		write(dsp_fd, buf, get_num);
		if (get_num != num)
		{
			fclose(file_fd);
			return 0;
		}
	}
#endif
	///
	fclose(file_fd);
	return 0;
}

int main() {
	int value;

	Audio_Play_Init(44100, 2, 16);

	//value = P8100_Audio_Play("/root/ljr.wav", 44100, 2, 16); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/C4.wav");//注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/D4.wav"); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/E4.wav"); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/F4.wav"); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/G4.wav"); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/A4.wav"); //注意播放文件的路径哦！！
	value = P8100_Audio_Play("/root/Piano/B4.wav"); //注意播放文件的路径哦！！
	fprintf(stderr, "value is %d", value);
	return 0;
}

#endif
